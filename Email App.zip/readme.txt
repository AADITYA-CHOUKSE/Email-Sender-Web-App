hello bro ,

to run this first of all install all packages with npm '
if you are using this project from github .

like - express , hbs , nodemailer , body-parser , dotenv , nodemailer install all.


then just open your terminal 
and write  =>  nodemon index.js 
you have to only run index.js file thats it .


- and as it open in server just enter email of yours or any person whome you want to 
send email and just write a message for him/her .


Thankyou

-- i am Awesome 'Aaditya'----------



